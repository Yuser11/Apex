import express from "express";
import controllerRaiz from "../controller/controllerRoot.js";


// import controllerImage from "../controller/controllerImage.js";
// import controllerVeiculo from "../controller/controllerVeiculo.js";

const routers = express();

routers.use(express.json());

routers.get("/", controllerRaiz.raiz);

// routers.get('/veiculos', controllerVeiculo.listar)

// routers.post('/image', controllerImage.salvar)

export default routers;
